/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Queue.h
 * Author: denniss
 *
 * Created on June 23, 2017, 9:30 AM
 */

#ifndef LIST_H
#define LIST_H

#include "../ListElement/ListElement.h"


class List
{

public:
    List( );

    void add_element( int val );
    int remove_element( );
    void print( );
    ListElement * search( int val );
    void delete_node( int val );

    bool empty;
    
    ListElement * head;
    ListElement * tail;
    
private:

} ;

#endif /* QUEUE_H */
