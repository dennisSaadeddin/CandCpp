/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   List.cpp
 * Author: denniss
 * 
 * Created on June 23, 2017, 9:30 AM
 */

#include <string.h>
#include "List/List.h"
#include "../ListWithPointers/ListElement/ListElement.h"

#include <iostream>

using namespace std;

List::List( )
{
    head = NULL;
    tail = NULL;
    empty = true;
}

void List::add_element( int val )
{
    ListElement * node = new ListElement( val );

    if ( head == NULL )
    {
        head = node;
    }
    if ( tail != NULL )
    {
        tail->next = node;
    }
    tail = node;

    empty = false;

}

//int List::remove_element( )
//{
//    int storeData = 0;
//
//    if ( empty )
//    {
//        std::cout << "The List is empty." << std::endl;
//    }
//
//    else
//    {
//        ListElement * temp = head;
//        storeData = head->nodeData;
//        head = head->next;
//        delete temp;
//    }
//
//    empty = ( head == NULL );
//
//    return storeData;
//}

ListElement * List::search( int val )
{
    for ( ListElement * temp = head; temp != NULL; temp = temp-> next )
    {
        if ( temp->nodeData == val )
        {
            return temp; // found the element
        }
    }
    
    return NULL; // didn't find anything
}

void List::delete_node( int val )
{
    ListElement * tmp = new ListElement( 0 );
    tmp = search( val ); // search for the val to be deleted

    for ( ListElement * index = head; index != NULL; index ++ )
    {
        if ( index->next->nodeData == tmp->nodeData )
        {
            index->next = tmp->next;
            delete tmp;
        }
    }
}

void List::print( )
{
    // i is a copy of the head, so I don't have to move the head around, thus changing its value.
    ListElement * i = head;

    while ( i != NULL )
    {
        std::cout << i->nodeData << " ";
        i = i->next;
    }

    std::cout << std::endl;
}
